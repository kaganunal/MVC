﻿namespace KitapYazarApi.DTO
{
    public class CreateTypeOfBookDTO
    {
        public string Type { get; set; }
    }
}
