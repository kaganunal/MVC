﻿namespace KitapYazarApi.DTO
{
    public class CreateAuthorDTO
    {
        public string Name { get; set; }


    }
}
