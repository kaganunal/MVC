﻿namespace KitapYazarApi.DTO
{
    public class EditAuthorDTO
    {
        public int AuthorId { get; set; }
        public string Name { get; set; }
    }
}
