﻿namespace KitapYazarApi.DTO
{
    public class EditTypeOfBookDTO
    {
        public int TypeOfBookId { get; set; }
        public string Type { get; set; }
    }
}
