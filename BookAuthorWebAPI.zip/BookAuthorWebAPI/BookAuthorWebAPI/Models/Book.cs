﻿namespace BookAuthorWebAPI.Models
{
    public class Book
    {
        public Book()
        {
            BookTypeOfBooks = new HashSet<BookTypeOfBook>();
        }
        public int Id { get; set; }
        public int Name { get; set; }
        public ICollection<BookTypeOfBook> BookTypeOfBooks { get; set; }
        public Author Author { get; set; }
    }
}
