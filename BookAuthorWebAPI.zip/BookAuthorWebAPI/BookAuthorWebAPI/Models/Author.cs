﻿namespace BookAuthorWebAPI.Models
{
    public class Author
    {
        public Author()
        {
            Books = new HashSet<Book>();
        }
        public int Id { get; set; }
        public int Name { get; set; }
        public ICollection<Book> Books { get; set; }
    }
}
